JAXB 2.1.x XJC Boolean-Getter Plugin
This plugin causes getter methods for Boolean Objects to be called "getXX" instead of "isXX".

Downloaded from 
http://fisheye5.atlassian.com/browse/~raw,r=1.1/jaxb2-commons/www/boolean-getter/index.html
on 18/03/10

Yiannis Paschalidis
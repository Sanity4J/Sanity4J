package packagg.subpackage2;

public class ClassThree
{
   public ClassThree()
   {
      System.out.println("Here");
   }
}

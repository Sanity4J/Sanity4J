package packagg.subpackage1;

public class ClassTwo
{
   public ClassTwo()
   {
      System.out.println("Here");
   }
}
